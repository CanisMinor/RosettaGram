#ifndef REPLACERARE_H
#define REPLACERARE_H

int replaceRare();

#endif

