#ifndef WORDCOUNT_H
#define WORDCOUNT_H

std::map<std::string, int> wordCounts(const std::string);

#endif
