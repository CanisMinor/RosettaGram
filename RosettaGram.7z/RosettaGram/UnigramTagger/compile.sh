#!/bin/bash

g++ main.cpp wordCount.cpp replaceRare.cpp emissionParameters.cpp -O2 -o rosettaUniGram


